/* =====================================================================
   store.js  -  Shared cart/"session" logic (localStorage, no backend),
   plus the shared navbar + footer rendering and WhatsApp checkout.
   ===================================================================== */

const CART_KEY = "cart";
const CFG = window.STORE_CONFIG;
const money = (n) => `${CFG.currency}${Number(n || 0).toLocaleString("en-IN")}`;

/* ---------- cart "session" (kept in browser localStorage) ---------- */
const getCart = () => {
  try { return JSON.parse(localStorage.getItem(CART_KEY)) || []; }
  catch { return []; }
};
const setCart = (cart) => {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartCount();
};
const cartCount = () => getCart().reduce((s, i) => s + i.quantity, 0);
const cartTotal = () => getCart().reduce((s, i) => s + (Number(i.price) || 0) * i.quantity, 0);

function addToCart(item, qty = 1) {
  const cart = getCart();
  const found = cart.find((i) => i.id === item.id);
  if (found) found.quantity += qty;
  else cart.push({ ...item, quantity: qty });
  setCart(cart);
  bumpCartIcon();
}
function setQuantity(id, qty) {
  let cart = getCart();
  const it = cart.find((i) => i.id === id);
  if (it) {
    it.quantity = qty;
    cart = cart.filter((i) => i.quantity > 0);
    setCart(cart);
  }
}
function removeFromCart(id) {
  setCart(getCart().filter((i) => i.id !== id));
}
function clearCart() {
  localStorage.removeItem(CART_KEY);
  updateCartCount();
}

function updateCartCount() {
  const c = cartCount();
  document.querySelectorAll(".js-cart-count").forEach((el) => {
    el.textContent = c;
    el.classList.toggle("is-empty", c === 0);
  });
}
function bumpCartIcon() {
  document.querySelectorAll(".js-cart-link").forEach((el) => {
    el.classList.remove("cart-bump");
    void el.offsetWidth;
    el.classList.add("cart-bump");
  });
}

/* ---------- WhatsApp order (no backend checkout) ------------------- */
function buildWhatsAppOrder(shipping) {
  const cart = getCart();
  let msg = `*New Order — ${CFG.storeName}*\n\n`;
  if (shipping) {
    msg += `*Name:* ${shipping.name}\n`;
    msg += `*Floor/Unit:* ${shipping.floor}\n`;
    msg += `*Area:* ${shipping.area}\n`;
    msg += `*State:* ${shipping.state}\n\n`;
  }
  msg += `*Items:*\n`;
  cart.forEach((it, i) => {
    const line = it.price
      ? `${money(it.price * it.quantity)}`
      : "Price on request";
    msg += `${i + 1}. ${it.name}  (${it.color || "—"})  x${it.quantity}  — ${line}\n`;
  });
  msg += `\n*Total:* ${money(cartTotal())}`;
  return `https://wa.me/${CFG.whatsappNumber}?text=${encodeURIComponent(msg)}`;
}

/* ---------- shared navbar + footer --------------------------------- */
function renderChrome(active) {
  const links = [
    ["index.html", "Home"],
    ["products.html", "Sarees"],
    ["about.html", "About"],
    ["contact.html", "Contact"],
  ];
  const navItems = links.map(
    ([href, label]) =>
      `<a href="${href}" class="nav-link ${active === href ? "active" : ""}">${label}</a>`
  ).join("");

  const header = document.querySelector("[data-chrome='header']");
  if (header) {
    header.innerHTML = `
      <nav class="navbar" id="navbar">
        <div class="nav-inner">
          <a href="index.html" class="brand">
            <span class="brand-text">${CFG.storeName}</span>
          </a>
          <div class="nav-links" id="navLinks">
            ${navItems}
          </div>
          <div class="nav-right">
            <a href="cart.html" class="nav-cart js-cart-link" aria-label="Cart">
              <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8">
                <path d="M3 3h2l.4 2M7 13h10l3-8H6.4M7 13L5.4 5M7 13l-2 4h12" stroke-linecap="round" stroke-linejoin="round"/>
                <circle cx="9" cy="20" r="1.4"/><circle cx="17" cy="20" r="1.4"/>
              </svg>
              <span class="js-cart-count cart-badge">0</span>
            </a>
            <button class="nav-toggle" id="navToggle" aria-label="Menu" aria-expanded="false">
              <span></span><span></span><span></span>
            </button>
          </div>
        </div>
      </nav>`;

    const toggle = header.querySelector("#navToggle");
    const linksEl = header.querySelector("#navLinks");
    const setOpen = (open) => {
      linksEl.classList.toggle("open", open);
      toggle.classList.toggle("is-open", open);
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    };
    toggle.addEventListener("click", () => setOpen(!linksEl.classList.contains("open")));
    linksEl.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => setOpen(false)));

    const nav = header.querySelector("#navbar");
    const onScroll = () => nav.classList.toggle("scrolled", window.scrollY > 30);
    window.addEventListener("scroll", onScroll);
    onScroll();
  }

  const footer = document.querySelector("[data-chrome='footer']");
  if (footer) {
    footer.innerHTML = `
      <div class="footer-inner">
        <div class="footer-col">
          <h4>${CFG.storeName}</h4>
          <p>${CFG.tagline}</p>
          <p class="muted">${CFG.address}</p>
        </div>
        <div class="footer-col">
          <h4>Shop</h4>
          <a href="products.html">All Sarees</a>
          <a href="cart.html">My Cart</a>
          <a href="about.html">About Us</a>
        </div>
        <div class="footer-col">
          <h4>Reach Us</h4>
          <a href="https://wa.me/${CFG.whatsappNumber}" target="_blank">WhatsApp</a>
          <a href="mailto:${CFG.email}">${CFG.email}</a>
          <a href="tel:${CFG.phone}">${CFG.phone}</a>
        </div>
      </div>
      <div class="footer-bottom">© ${new Date().getFullYear()} ${CFG.storeName}. Made with ♥ in India.</div>`;
  }

  // Floating WhatsApp button
  if (!document.querySelector(".wa-float")) {
    const a = document.createElement("a");
    a.href = `https://wa.me/${CFG.whatsappNumber}`;
    a.target = "_blank";
    a.className = "wa-float";
    a.title = "Chat on WhatsApp";
    a.innerHTML = `<svg viewBox="0 0 32 32" width="28" height="28" fill="currentColor"><path d="M16 .5C7.4.5.5 7.4.5 16c0 2.8.8 5.5 2.2 7.9L.5 31.5l7.8-2.1C10.6 30.7 13.2 31.5 16 31.5 24.6 31.5 31.5 24.6 31.5 16S24.6.5 16 .5zm0 28c-2.5 0-4.9-.7-7-1.9l-.5-.3-4.6 1.2 1.2-4.5-.3-.5C3.4 20.9 2.7 18.5 2.7 16 2.7 8.6 8.6 2.7 16 2.7S29.3 8.6 29.3 16 23.4 28.5 16 28.5zm7.4-9.2c-.4-.2-2.4-1.2-2.7-1.3-.4-.1-.6-.2-.9.2s-1 1.3-1.3 1.5c-.2.2-.5.3-.9.1-.4-.2-1.7-.6-3.2-2-1.2-1-2-2.4-2.2-2.8-.2-.4 0-.6.2-.8l.6-.7c.2-.2.3-.4.4-.7.1-.2.1-.5 0-.7-.1-.2-.9-2.2-1.3-3-.3-.8-.6-.7-.9-.7h-.7c-.2 0-.6.1-.9.4-.3.4-1.2 1.2-1.2 2.9s1.2 3.4 1.4 3.6c.2.2 2.4 3.7 5.9 5.2.8.4 1.5.6 2 .7.8.3 1.6.2 2.2.1.7-.1 2.1-.9 2.4-1.7.3-.8.3-1.5.2-1.7-.1-.2-.4-.3-.8-.5z"/></svg>`;
    document.body.appendChild(a);
  }

  // Inject a gold "TE" favicon so every page has a branded tab icon.
  if (!document.querySelector("link[rel='icon']")) {
    const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'>
      <rect width='64' height='64' rx='14' fill='%235b0e2d'/>
      <text x='50%' y='54%' dominant-baseline='middle' text-anchor='middle'
        font-family='Georgia,serif' font-size='30' font-weight='700' fill='%23e8d39a'>TE</text></svg>`;
    const link = document.createElement("link");
    link.rel = "icon";
    link.type = "image/svg+xml";
    link.href = "data:image/svg+xml," + svg.replace(/\n\s*/g, "");
    document.head.appendChild(link);
  }

  updateCartCount();
}

/* expose */
Object.assign(window, {
  getCart, setCart, addToCart, setQuantity, removeFromCart, clearCart,
  cartCount, cartTotal, updateCartCount, buildWhatsAppOrder, renderChrome, money,
});
